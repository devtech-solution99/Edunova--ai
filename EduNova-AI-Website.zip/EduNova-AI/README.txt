EduNova AI - Website Prototype

Main website file: index.html

To deploy with Firebase Hosting, upload the extracted website files to your hosting public directory using Firebase CLI or an appropriate deployment workflow.

Note: This is a frontend prototype. Login and AI assistant are demo interfaces and are not connected to real authentication or a live AI model yet.
